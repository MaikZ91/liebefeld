import { GoogleGenAI, Type } from "@google/genai";
import { EventItem, UserProfile, ConnectionSuggestion } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getTribeResponse = async (userMessage: string, availableEvents: EventItem[]): Promise<{ text: string; relatedEvents: EventItem[] }> => {
  const eventContext = JSON.stringify(availableEvents.slice(0, 40));

  const systemInstruction = `
    Identity: THE CONCIERGE // TRIBE_NETWORK
    Tone: Sophisticated, urban, exclusive, concise.
    Language: German.
    Style: High-end nightlife guide. Use words like "Vibe", "Atmosphäre", "Essential".
    
    Task: Provide curated event intelligence based on user input. Answer in German.
    
    Return JSON format:
    {
      "reply": "RESPONSE TEXT IN GERMAN",
      "recommended_event_indices": [0, 5]
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `INPUT: "${userMessage}"\n\nDATA_STREAM: ${eventContext}`,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            reply: { type: Type.STRING },
            recommended_event_indices: { 
              type: Type.ARRAY, 
              items: { type: Type.INTEGER } 
            }
          }
        }
      }
    });

    const rawText = response.text || "{}";
    const parsed = JSON.parse(rawText);
    
    const relatedEvents = (parsed.recommended_event_indices || []).map((idx: number) => availableEvents[idx]).filter(Boolean);

    return {
      text: parsed.reply || "Zu dieser Anfrage habe ich momentan keine Informationen.",
      relatedEvents
    };

  } catch (error) {
    return {
      text: "Sichere Verbindung momentan nicht verfügbar.",
      relatedEvents: []
    };
  }
};

export const generateEventSummary = async (event: EventItem): Promise<string> => {
    const prompt = `
    Analyze this event: "${event.event}" (${event.category}). Description: "${event.description || 'No data'}".
    Create a 2-sentence "Insider Summary" for a nightlife app in German. 
    Focus on the vibe, music genre, and why it's worth going. 
    Do not use promotional language, keep it cool and informative.
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        return response.text || "Keine Informationen verfügbar.";
    } catch (e) {
        return "Analyse fehlgeschlagen.";
    }
};

export const enhancePostContent = async (rawText: string): Promise<{ optimizedText: string; hashtags: string[] }> => {
  const prompt = `
  Act as a social media expert for an exclusive urban nightlife app ("The Tribe").
  Task: Optimize the following user post draft.
  1. Make the text sound cooler, more engaging, and authentic (Urban/Berlin Vibe). Keep it German.
  2. Generate 3-5 relevant, trending hashtags (without #).
  
  Draft: "${rawText}"
  `;

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    optimizedText: { type: Type.STRING },
                    hashtags: { type: Type.ARRAY, items: { type: Type.STRING } }
                }
            }
        }
    });
    
    const json = JSON.parse(response.text || "{}");
    return {
        optimizedText: json.optimizedText || rawText,
        hashtags: json.hashtags || ['Community', 'Tribe']
    };
  } catch (e) {
      return { optimizedText: rawText, hashtags: [] };
  }
};

export const generateEventImage = async (event: EventItem): Promise<string | null> => {
  try {
    const prompt = `Cinematic high contrast photography of "${event.event}". 
    Style: Berlin techno club flyer, raw, gritty, flash photography, vibrant neon colors.
    Subject: Authentic nightlife crowd, industrial architecture, or abstract strobe lights.
    Lighting: Deep shadows, rich atmospheric lighting, cinematic bokeh.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        imageConfig: {
          aspectRatio: "4:3" 
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData && part.inlineData.data) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Image generation failed:", error);
    return null;
  }
};

export const getAIConnections = async (userProfile: UserProfile, communityPosts: any[]): Promise<ConnectionSuggestion[]> => {
  return [];
};