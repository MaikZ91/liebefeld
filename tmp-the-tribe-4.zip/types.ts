

export interface EventItem {
  date: string;
  time?: string | null;
  event: string;
  category?: string;
  description?: string;
  link: string;
  image_url?: string | null;
  city?: string;
  // New Expert Features
  matchScore?: number; // 0-100
  attendees?: number; // Count of people going
  vibe?: 'RAGE' | 'CHILL' | 'ARTSY' | 'FLIRTY';
  summary?: string; // AI Generated summary
  attendeeAvatars?: string[]; // Mockup avatars
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  isLoading?: boolean;
  relatedEvents?: EventItem[];
}

export interface UserProfile {
  username: string;
  bio: string;
  avatarUrl: string; 
}

export interface Comment {
  id: string;
  user: string;
  text: string;
  time: string;
  userAvatar?: string;
}

export interface Post {
  id: string;
  user: string;
  text: string;
  city: string;
  likes: number;
  time: string;
  tags: string[];
  userAvatar?: string;
  comments?: Comment[];
  isCrewCall?: boolean;
}

export enum ViewState {
  FEED = 'FEED',
  TRIBE_AI = 'TRIBE_AI',
  COMMUNITY = 'COMMUNITY',
  MAP = 'MAP'
}

export interface ConnectionSuggestion {
  userId: string;
  username: string;
  matchScore: number;
  reason: string;
}