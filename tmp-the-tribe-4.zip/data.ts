
import { Post, EventItem } from './types';

export const INITIAL_POSTS: Post[] = [
  { id: '1', user: 'NeonGhost', text: 'Running group for *TRIBE TUESDAY*? I need a pacer for 5:30 pace!', city: 'Bielefeld', likes: 12, time: '2h ago', tags: ['Sport', 'Run'] },
  { id: '2', user: 'CyberPunk_99', text: 'Anyone hitting the "Nachtarena Revival"? Looking for a crew to pre-drink.', city: 'Bielefeld', likes: 5, time: '4h ago', tags: ['Party', 'Connect'] },
  { id: '3', user: 'ArtVandal', text: 'Is the Sip&Sketch event BYOB or is there a bar?', city: 'Bielefeld', likes: 2, time: '5h ago', tags: ['Art', 'Question'] },
  { id: '4', user: 'TechnoViking', text: 'Just arrived in Dortmund. Where is the bass tonight? FZW or Junkyard?', city: 'Dortmund', likes: 8, time: '10m ago', tags: ['Party', 'Techno'] },
  { id: '5', user: 'Lisa_F', text: 'Has anyone tickets left for 01099 in Stuttgart? 🥺', city: 'Stuttgart', likes: 1, time: '30m ago', tags: ['Ticket', 'Search'] },
];

export const FALLBACK_EVENTS: EventItem[] = [
  {
    date: 'Fr, 28.11.2025',
    time: '23:00',
    event: 'Neon Nights: Cyberpunk Rave',
    category: 'Party',
    description: 'The ultimate futuristic rave experience. Dress code: Neon & Chrome.',
    link: '#',
    image_url: null,
    city: 'Bielefeld'
  },
  {
    date: 'Sa, 29.11.2025',
    time: '20:00',
    event: 'Digital Art Vernissage',
    category: 'Art',
    description: 'Showcasing local digital artists. VR experiences included.',
    link: '#',
    image_url: null,
    city: 'Berlin'
  },
  {
    date: 'Su, 30.11.2025',
    time: '14:00',
    event: 'Community Run: Urban Trail',
    category: 'Sport',
    description: '10k run through the industrial sector.',
    link: '#',
    image_url: null,
    city: 'Hamburg'
  },
  {
    date: 'Fr, 05.12.2025',
    time: '21:00',
    event: 'Underground Comedy Club',
    category: 'Comedy',
    description: 'Secret location comedy show. Password required.',
    link: '#',
    image_url: null,
    city: 'Cologne'
  },
  {
    date: 'Sa, 06.12.2025',
    time: '22:00',
    event: 'Retro Synthwave Party',
    category: 'Party',
    description: '80s vibes and synthwave beats all night long.',
    link: '#',
    image_url: null,
    city: 'Munich'
  }
];
